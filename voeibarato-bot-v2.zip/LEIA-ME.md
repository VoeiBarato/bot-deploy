# Voei Barato Bot v2 — instalação na VPS

## Arquivos

| Arquivo | Função |
|---|---|
| `fluxo.py` | **Novo.** Motor de conversa compartilhado (perguntas, validações, timer, formato do pedido) |
| `bot.py` | Bot Telegram — reescrito, agora usa só `requests` (sem python-telegram-bot) |
| `whatsapp_bot.py` | Bot WhatsApp (Flask + Evolution API) — reescrito |
| `docker-compose.yml` | Atualizado: passa a montar o `fluxo.py` |
| `docker-compose-whatsapp.yml` | Atualizado: idem |

Todos vão para `/opt/voeibarato/`.

---

## Passo a passo (SSH na VPS)

```bash
cd /opt/voeibarato

# 1. Backup do que já existe
mkdir -p backup-v1
cp bot.py whatsapp_bot.py docker-compose*.yml backup-v1/ 2>/dev/null

# 2. Subir os 5 arquivos novos para /opt/voeibarato/
#    (ver seção "Como transferir" abaixo)

# 3. Derrubar os containers antigos
docker stop voeibarato-bot voeibarato-whatsapp
docker rm voeibarato-bot voeibarato-whatsapp

# 4. Subir os novos
docker compose up -d
docker compose -f docker-compose-whatsapp.yml up -d

# 5. Conferir
sleep 40
docker logs voeibarato-bot 2>&1 | tail -10
docker logs voeibarato-whatsapp 2>&1 | tail -10
curl -s localhost:5001/health
```

Esperado no health: `{"sessoes":0,"status":"ok"}`

---

## Webhook (só se parar de funcionar)

O webhook deve apontar para o **nome do container**, não para o IP — assim não quebra
quando a VPS reinicia:

```bash
curl -s -X POST "http://localhost:8080/webhook/set/voeibarato" \
  -H "apikey: voeibarato2026" -H "Content-Type: application/json" \
  -d '{"url":"http://voeibarato-whatsapp:5001/webhook",
       "webhookByEvents":false,"webhookBase64":false,
       "events":["MESSAGES_UPSERT"]}'
```

---

## Rotas úteis do bot WhatsApp

| Rota | O que faz |
|---|---|
| `curl localhost:5001/health` | Bot vivo? Quantas sessões ativas? |
| `curl localhost:5001/sessoes` | Lista quem está conversando e em que etapa |
| `curl -X POST localhost:5001/reset/5521999998888` | Libera um número que foi transferido para humano (o bot volta a atender) |

No Telegram, o próprio cliente pode escrever **reiniciar** para começar de novo.

---

## Como testar o fluxo

1. Mande "oi" no WhatsApp `5521997628119` → bot pede o nome
2. Responda tudo até o fim → pedido cai no grupo "Voei Barato - Pedidos"
3. Teste o erro: mande um e-mail inválido 3 vezes → deve transferir para humano
4. Teste o modo descoberta: responda "não" em "já sabe para onde quer ir?"

---

## Comandos que o cliente pode usar

| Comando | Efeito |
|---|---|
| `reiniciar` / `/start` | Recomeça o pedido do zero |
| `cancelar` / `/cancelar` | Apaga a sessão |
| `atendente` / `humano` | Transfere direto para a equipe |
| `/id` (só Telegram) | Mostra o ID do chat |

---

## Ajustes rápidos

- **Timer de inatividade:** variável `TIMEOUT_MIN` nos dois docker-compose (padrão 20).
  O encerramento silencioso acontece em `TIMEOUT_MIN × 2` (40 min).
- **Tentativas antes de transferir:** `MAX_ERROS` no topo do `fluxo.py` (padrão 3).
- **Textos das perguntas:** função `pergunta()` no `fluxo.py` — muda ali e vale para os dois canais.
- **Formato do pedido no grupo:** função `montar_pedido()` no `fluxo.py`.

Depois de editar qualquer arquivo, é só reiniciar:
```bash
docker restart voeibarato-bot voeibarato-whatsapp
```

---

## Observações

- **As sessões ficam em memória.** Se reiniciar o container, quem estava no meio do
  atendimento perde o progresso e recomeça. Os pedidos **finalizados** estão salvos em
  `/opt/voeibarato/pedidos/` e no grupo do Telegram, então nada se perde.
- **Bebês também precisam de CPF** — a Receita hoje emite CPF desde o nascimento, e as
  cias exigem. Por isso o bot pede CPF de todos.
- **Flask em modo desenvolvimento** aguenta bem o volume atual. Passando de ~50 conversas
  simultâneas, vale trocar por gunicorn (mas aí as sessões precisam ir para o Redis, que
  já está rodando na VPS).
