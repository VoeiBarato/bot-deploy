"""
Voei Barato - Motor de fluxo compartilhado (WhatsApp + Telegram)
Versao 2.0

Este modulo contem TODA a logica de conversa. Os arquivos bot.py (Telegram)
e whatsapp_bot.py (WhatsApp/Evolution) apenas enviam e recebem mensagens.
"""

import os
import re
import time
import logging
import unicodedata
import threading
from datetime import datetime, timedelta

PEDIDOS_DIR = os.getenv("PEDIDOS_DIR", "/app/pedidos")
TIMEOUT_MIN = int(os.getenv("TIMEOUT_MIN", "20"))
MAX_ERROS = 3          # na 3a falha consecutiva -> transfere para humano
MAX_PAX = 9

MESES = ["janeiro", "fevereiro", "marco", "abril", "maio", "junho",
         "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]
MESES_NOME = ["Janeiro", "Fevereiro", "Marco", "Abril", "Maio", "Junho",
              "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]


# ---------------------------------------------------------------- utilidades

def norm(t):
    """minusculo, sem acento, sem espacos nas pontas"""
    t = unicodedata.normalize("NFD", (t or "").strip().lower())
    return "".join(c for c in t if unicodedata.category(c) != "Mn")


def so_digitos(t):
    return re.sub(r"\D", "", t or "")


def escolher(texto, opcoes):
    """
    Aceita: numero da opcao (1, 2, 3...) ou o texto (com/sem acento, parcial).
    Retorna a opcao oficial ou None.
    """
    t = norm(texto)
    if not t:
        return None
    if t.isdigit():
        i = int(t) - 1
        if 0 <= i < len(opcoes):
            return opcoes[i]
        return None
    for o in opcoes:
        if norm(o) == t:
            return o
    for o in opcoes:
        no = norm(o)
        if t in no or no in t:
            return o
    # apelidos comuns
    apelidos = {
        "s": "Sim", "sim": "Sim", "isso": "Sim", "ja sei": "Sim", "claro": "Sim",
        "n": "Nao", "nao": "Nao", "ainda nao": "Nao", "nem ideia": "Nao",
        "tanto faz": "Tanto faz", "indiferente": "Tanto faz", "qualquer": "Tanto faz",
    }
    alvo = apelidos.get(t)
    if alvo:
        for o in opcoes:
            if norm(o) == norm(alvo):
                return o
    return None


MINUSCULAS = {"de", "da", "do", "das", "dos", "e", "d'"}


def titulo(t):
    """Title-case respeitando conectores: 'rio de janeiro' -> 'Rio de Janeiro'."""
    palavras = (t or "").strip().split()
    out = []
    for i, p in enumerate(palavras):
        pl = p.lower()
        out.append(pl if (i > 0 and pl in MINUSCULAS) else pl.capitalize())
    return " ".join(out)


def validar_email(t):
    t = (t or "").strip()
    if re.match(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$", t):
        return t.lower()
    return None


def validar_data(t):
    """Aceita dd/mm/aaaa, dd-mm-aaaa, dd.mm.aaaa, ddmmaaaa, dd/mm. Retorna date futura."""
    t = (t or "").strip()
    d = so_digitos(t)
    hoje = datetime.now().date()
    tentativas = []
    if len(d) == 8:
        tentativas.append((int(d[0:2]), int(d[2:4]), int(d[4:8])))
    elif len(d) == 6:
        tentativas.append((int(d[0:2]), int(d[2:4]), 2000 + int(d[4:6])))
    elif len(d) == 4:
        tentativas.append((int(d[0:2]), int(d[2:4]), hoje.year))
        tentativas.append((int(d[0:2]), int(d[2:4]), hoje.year + 1))
    else:
        return None
    for dia, mes, ano in tentativas:
        try:
            dt = datetime(ano, mes, dia).date()
        except ValueError:
            continue
        if dt > hoje:
            return dt
    return None


def validar_valor(t):
    """Orcamento: aceita 800, R$ 800, 1.200,50, 1200.50"""
    t = norm(t).replace("r$", "").replace(" ", "").replace("reais", "")
    t = t.replace(".", "").replace(",", ".")
    t = re.sub(r"[^\d.]", "", t)
    try:
        v = float(t)
    except ValueError:
        return None
    return v if v > 0 else None


def validar_telefone(t):
    d = so_digitos(t)
    if d.startswith("55") and len(d) in (12, 13):
        d = d[2:]
    if len(d) in (10, 11):
        return d
    return None


def formatar_telefone(d):
    if len(d) == 11:
        return f"({d[0:2]}) {d[2:7]}-{d[7:]}"
    if len(d) == 10:
        return f"({d[0:2]}) {d[2:6]}-{d[6:]}"
    return d


def validar_cpf(t):
    c = so_digitos(t)
    if len(c) != 11 or c == c[0] * 11:
        return None
    for i in (9, 10):
        soma = sum(int(c[j]) * ((i + 1) - j) for j in range(i))
        dig = (soma * 10) % 11
        dig = 0 if dig == 10 else dig
        if dig != int(c[i]):
            return None
    return f"{c[0:3]}.{c[3:6]}.{c[6:9]}-{c[9:]}"


def validar_inteiro(t, minimo=0, maximo=99):
    d = so_digitos(t)
    palavras = {"nenhum": 0, "nenhuma": 0, "zero": 0, "um": 1, "uma": 1, "dois": 2,
                "duas": 2, "tres": 3, "quatro": 4, "cinco": 5, "seis": 6,
                "sete": 7, "oito": 8, "nove": 9}
    if not d:
        v = palavras.get(norm(t))
        if v is None:
            return None
    else:
        v = int(d)
    return v if minimo <= v <= maximo else None


def validar_mes(t):
    n = norm(t)
    d = so_digitos(t)
    if d and 1 <= int(d) <= 12:
        return MESES_NOME[int(d) - 1]
    for i, m in enumerate(MESES):
        if n and (n in m or m in n):
            return MESES_NOME[i]
    return None


# ---------------------------------------------------------------- sessao

class Sessao:
    def __init__(self, canal, user_id):
        self.canal = canal            # "WhatsApp" ou "Telegram"
        self.user_id = str(user_id)
        self.step = "nome"
        self.iniciada = False         # True depois que a saudacao foi enviada
        self.dados = {}
        self.passageiros = []         # [{"nome":..., "cpf":...}]
        self.pax_idx = 0
        self.erros = 0
        self.transferido = False
        self.finalizado = False
        self.ultima = time.time()
        self.lembrete_enviado = False

    def toca(self):
        self.ultima = time.time()
        self.lembrete_enviado = False

    def inativa_min(self):
        return (time.time() - self.ultima) / 60.0

    @property
    def nome(self):
        return self.dados.get("nome", "")

    @property
    def total_pax(self):
        return (self.dados.get("adultos", 0)
                + self.dados.get("criancas", 0)
                + self.dados.get("bebes", 0))


SESSOES = {}
_LOCK = threading.Lock()


def get_sessao(canal, user_id, criar=True):
    chave = f"{canal}:{user_id}"
    with _LOCK:
        s = SESSOES.get(chave)
        if s is None and criar:
            s = Sessao(canal, user_id)
            SESSOES[chave] = s
        return s


def apagar_sessao(canal, user_id):
    with _LOCK:
        SESSOES.pop(f"{canal}:{user_id}", None)


# ---------------------------------------------------------------- perguntas

OPCOES = {
    "proposito": ["Trabalho", "Lazer"],
    "escopo": ["Nacional", "Internacional", "Tanto faz"],
    "sabe_destino": ["Sim", "Não"],
    "flexibilidade": ["±3 dias", "Flexível no mês", "Datas fixas"],
    "clima": ["Calor", "Frio", "Tanto faz"],
    "estilo": ["Praia", "Cachoeira", "Cidade", "Qualquer"],
    "pax_quando": ["Preencher agora", "Preencher depois"],
}


def pergunta(sessao):
    """Retorna (texto, opcoes) da etapa atual."""
    s, d = sessao.step, sessao.dados
    nome = d.get("nome", "")

    if s == "nome":
        return ("Olá! Bem-vindo(a) à *Voei Barato* ✈️\n"
                "Passagens aéreas com até 60% de desconto usando milhas.\n\n"
                "Para começar, qual o seu nome?"), None
    if s == "email":
        return f"Prazer, {nome}! 😊\nQual o seu melhor e-mail?", None
    if s == "proposito":
        return "Qual o propósito da viagem?", OPCOES["proposito"]
    if s == "escopo":
        return "A viagem é nacional ou internacional?", OPCOES["escopo"]
    if s == "sabe_destino":
        return "Você já sabe para onde quer ir?", OPCOES["sabe_destino"]

    # ---- Fluxo A (destino definido)
    if s == "origem_a":
        return "Perfeito! De qual cidade você vai *sair*?", None
    if s == "destino_a":
        return f"E para onde você quer *ir*, saindo de {d.get('origem','')}?", None
    if s == "data_ida":
        return ("Qual a data de *ida*? (formato dia/mês/ano, ex: 15/09/2026)"), None
    if s == "data_volta":
        return ("E a data de *volta*? (ex: 22/09/2026)\n"
                "Se for somente ida, escreva *somente ida*."), None
    if s == "flexibilidade":
        return "Você tem flexibilidade nas datas?", OPCOES["flexibilidade"]

    # ---- Fluxo B (modo descoberta)
    if s == "origem_b":
        return "Sem problema, a gente te ajuda a escolher! 😉\nDe qual cidade você vai *sair*?", None
    if s == "orcamento":
        return "Qual valor você pretende investir *por pessoa*? (somente o número, ex: 800)", None
    if s == "clima":
        return "Você prefere calor ou frio?", OPCOES["clima"]
    if s == "estilo":
        return "Que tipo de destino você curte mais?", OPCOES["estilo"]
    if s == "duracao":
        return "Quantos dias você pretende ficar?", None
    if s == "mes":
        return "Em qual mês você pretende viajar?", None

    # ---- Convergencia
    if s == "adultos":
        return "Agora os passageiros.\nQuantos *adultos* (12 anos ou mais)?", None
    if s == "criancas":
        return "Quantas *crianças* (2 a 11 anos)? Se nenhuma, responda 0.", None
    if s == "bebes":
        return "Quantos *bebês* (0 a 1 ano)? Se nenhum, responda 0.", None
    if s == "telefone":
        return "Qual o seu telefone com DDD? (ex: 21997628119)", None
    if s == "pax_quando":
        return (f"Você quer preencher os dados dos {sessao.total_pax} passageiro(s) agora "
                "ou prefere que nossa equipe colete depois?"), OPCOES["pax_quando"]
    if s == "pax_nome":
        return f"Passageiro {sessao.pax_idx + 1} de {sessao.total_pax}\nNome completo (como no documento):", None
    if s == "pax_cpf":
        p = sessao.passageiros[sessao.pax_idx]
        return f"CPF de {p['nome']}:", None
    return ("", None)


ERROS_MSG = {
    "email": "Hmm, esse e-mail não parece válido. Pode conferir? (ex: nome@email.com)",
    "data_ida": "Não consegui entender a data. Use o formato dia/mês/ano (ex: 15/09/2026) e uma data futura.",
    "data_volta": "Não consegui entender a data de volta. Use dia/mês/ano e uma data depois da ida.",
    "orcamento": "Preciso de um valor numérico maior que zero (ex: 800).",
    "telefone": "Telefone inválido. Envie com DDD, 10 ou 11 dígitos (ex: 21997628119).",
    "pax_cpf": "CPF inválido. Envie os 11 dígitos (ex: 12345678900).",
    "adultos": "Preciso de um número de adultos entre 1 e 9.",
    "criancas": "Preciso de um número entre 0 e 9.",
    "bebes": "Preciso de um numero entre 0 e 9.",
    "duracao": "Preciso de um número de dias entre 1 e 90.",
    "mes": "Não entendi o mês. Pode escrever o nome (ex: setembro) ou o número (ex: 9).",
    "pax_nome": "Preciso do nome completo (nome e sobrenome).",
}


def erro_msg(step, opcoes):
    if opcoes:
        lista = "\n".join(f"{i+1}. {o}" for i, o in enumerate(opcoes))
        return f"Não entendi. Escolha uma das opções:\n{lista}"
    return ERROS_MSG.get(step, "Não entendi, pode repetir?")


# ---------------------------------------------------------------- transicoes

LINEAR = {
    "nome": "email",
    "email": "proposito",
    "proposito": "escopo",
    "escopo": "sabe_destino",
    "origem_a": "destino_a",
    "destino_a": "data_ida",
    "data_ida": "data_volta",
    "data_volta": "flexibilidade",
    "flexibilidade": "adultos",
    "origem_b": "orcamento",
    "orcamento": "clima",
    "clima": "estilo",
    "estilo": "duracao",
    "duracao": "mes",
    "mes": "adultos",
    "adultos": "criancas",
    "criancas": "bebes",
    "bebes": "telefone",
    "telefone": "pax_quando",
}


def proximo(sessao):
    s = sessao.step
    if s == "sabe_destino":
        return "origem_a" if sessao.dados.get("sabe_destino") == "Sim" else "origem_b"
    if s == "pax_quando":
        return "pax_nome" if sessao.dados.get("pax_agora") else "fim"
    if s == "pax_nome":
        return "pax_cpf"
    if s == "pax_cpf":
        sessao.pax_idx += 1
        return "pax_nome" if sessao.pax_idx < sessao.total_pax else "fim"
    return LINEAR.get(s, "fim")


def aplicar(sessao, texto):
    """
    Valida a resposta da etapa atual e grava nos dados.
    Retorna True se valido, False se invalido.
    """
    s, d = sessao.step, sessao.dados
    t = (texto or "").strip()
    opcoes = OPCOES.get(s)

    if opcoes:
        v = escolher(t, opcoes)
        if not v:
            return False
        if s == "pax_quando":
            d["pax_agora"] = (v == "Preencher agora")
        else:
            d[s] = v
        return True

    if s == "nome":
        if len(t) < 2 or len(t) > 60:
            return False
        d["nome"] = titulo(t)
        return True
    if s == "email":
        v = validar_email(t)
        if not v:
            return False
        d["email"] = v
        return True
    if s in ("origem_a", "origem_b"):
        if len(t) < 2:
            return False
        d["origem"] = titulo(t)
        return True
    if s == "destino_a":
        if len(t) < 2:
            return False
        d["destino"] = titulo(t)
        return True
    if s == "data_ida":
        v = validar_data(t)
        if not v:
            return False
        d["data_ida"] = v
        return True
    if s == "data_volta":
        if norm(t) in ("somente ida", "so ida", "ida", "sem volta", "nao", "n"):
            d["data_volta"] = None
            return True
        v = validar_data(t)
        if not v or v < d.get("data_ida"):
            return False
        d["data_volta"] = v
        return True
    if s == "orcamento":
        v = validar_valor(t)
        if not v:
            return False
        d["orcamento"] = v
        return True
    if s == "duracao":
        v = validar_inteiro(t, 1, 90)
        if v is None:
            return False
        d["duracao"] = v
        return True
    if s == "mes":
        v = validar_mes(t)
        if not v:
            return False
        d["mes"] = v
        return True
    if s == "adultos":
        v = validar_inteiro(t, 1, MAX_PAX)
        if v is None:
            return False
        d["adultos"] = v
        return True
    if s in ("criancas", "bebes"):
        v = validar_inteiro(t, 0, MAX_PAX)
        if v is None:
            return False
        if sessao.dados.get("adultos", 0) + sessao.dados.get("criancas", 0) + v > MAX_PAX:
            return False
        d[s] = v
        return True
    if s == "telefone":
        v = validar_telefone(t)
        if not v:
            return False
        d["telefone"] = v
        return True
    if s == "pax_nome":
        if len(t.split()) < 2:
            return False
        sessao.passageiros.append({"nome": t.upper(), "cpf": "(preencher depois)"})
        return True
    if s == "pax_cpf":
        v = validar_cpf(t)
        if not v:
            return False
        sessao.passageiros[sessao.pax_idx]["cpf"] = v
        return True
    return False


# ---------------------------------------------------------------- pedido

def montar_pedido(sessao):
    d = sessao.dados
    L = []
    L.append(f"✈️ NOVO PEDIDO — VOEI BARATO ({sessao.canal})")
    L.append("━━━━━━━━━━━━━━━━━━━━━━")
    L.append(f"👤 Cliente: {d.get('nome','-')}")
    L.append(f"📧 E-mail: {d.get('email','-')}")
    L.append(f"📱 Telefone: {formatar_telefone(d.get('telefone',''))}")
    L.append(f"🎯 Propósito: {d.get('proposito','-')}")
    L.append(f"🌎 Escopo: {d.get('escopo','-')}")
    L.append("")
    if d.get("sabe_destino") == "Sim":
        L.append(f"📍 Trecho: {d.get('origem','-')} → {d.get('destino','-')}")
        ida = d.get("data_ida")
        L.append(f"📅 Ida: {ida.strftime('%d/%m/%Y') if ida else '-'}")
        volta = d.get("data_volta")
        L.append(f"📅 Volta: {volta.strftime('%d/%m/%Y') if volta else 'somente ida'}")
        L.append(f"📆 Flexibilidade: {d.get('flexibilidade','-')}")
    else:
        L.append("🔎 MODO DESCOBERTA")
        L.append(f"📍 Origem: {d.get('origem','-')}")
        L.append(f"💰 Orçamento: R$ {d.get('orcamento',0):.2f} / pessoa")
        L.append(f"🌡 Clima: {d.get('clima','-')}")
        L.append(f"🏖 Estilo: {d.get('estilo','-')}")
        L.append(f"⏱ Duração: {d.get('duracao','-')} dias")
        L.append(f"📅 Mês: {d.get('mes','-')}")
    L.append("")
    L.append(f"👥 Passageiros: {d.get('adultos',0)} adulto(s), "
             f"{d.get('criancas',0)} criança(s), {d.get('bebes',0)} bebê(s)")
    L.append("")
    if sessao.passageiros:
        for i, p in enumerate(sessao.passageiros, 1):
            L.append(f"Passageiro {i}:")
            L.append(f"  Nome: {p['nome']}")
            L.append(f"  CPF: {p['cpf']}")
    else:
        L.append("Dados dos passageiros: A COLETAR (cliente optou por preencher depois)")
    L.append("")
    L.append("━━━━━━━━━━━━━━━━━━━━━━")
    L.append(f"💬 Contato: {sessao.user_id}")
    L.append(f"🕐 Recebido: {datetime.now().strftime('%d/%m/%Y %H:%M')}")
    return "\n".join(L)


def salvar_pedido(texto, sessao):
    try:
        os.makedirs(PEDIDOS_DIR, exist_ok=True)
        nome = datetime.now().strftime("%Y%m%d_%H%M%S") + f"_{sessao.canal}_{sessao.user_id}.txt"
        caminho = os.path.join(PEDIDOS_DIR, re.sub(r"[^\w.\-]", "_", nome))
        with open(caminho, "w", encoding="utf-8") as f:
            f.write(texto)
        logging.info(f"Pedido salvo em {caminho}")
    except Exception as e:
        logging.error(f"Falha ao salvar pedido: {e}")


# ---------------------------------------------------------------- resposta

def _msg(texto, opcoes=None):
    return {"texto": texto, "opcoes": opcoes}


def _resultado(mensagens=None, pedido=None, alerta=None, transferido=False, encerrar=False):
    return {"mensagens": mensagens or [], "pedido": pedido,
            "alerta": alerta, "transferido": transferido, "encerrar": encerrar}


MSG_TRANSFERENCIA = ("Vou te transferir para um atendente, aguarde um momento! 🙋‍♂️\n"
                     "Nosso time responde por aqui em instantes.")


def transferir(sessao, motivo):
    sessao.transferido = True
    alerta = ("🚨 TRANSFERÊNCIA PARA ATENDIMENTO HUMANO\n"
              "━━━━━━━━━━━━━━━━━━━━━━\n"
              f"Canal: {sessao.canal}\n"
              f"Contato: {sessao.user_id}\n"
              f"Cliente: {sessao.dados.get('nome','(não informado)')}\n"
              f"E-mail: {sessao.dados.get('email','-')}\n"
              f"Etapa: {sessao.step}\n"
              f"Motivo: {motivo}\n"
              f"Hora: {datetime.now().strftime('%d/%m/%Y %H:%M')}")
    return _resultado(mensagens=[_msg(MSG_TRANSFERENCIA)], alerta=alerta, transferido=True)


def iniciar(sessao):
    sessao.iniciada = True
    txt, ops = pergunta(sessao)
    sessao.toca()
    return _resultado(mensagens=[_msg(txt, ops)])


def processar(sessao, texto):
    """Recebe a mensagem do cliente e devolve o que o bot deve fazer."""
    texto = (texto or "").strip()
    n = norm(texto)

    # comandos
    if n in ("/start", "/inicio", "reiniciar", "/reiniciar", "recomecar", "/reset"):
        sessao.__init__(sessao.canal, sessao.user_id)
        return iniciar(sessao)
    if n in ("/cancelar", "cancelar"):
        apagar_sessao(sessao.canal, sessao.user_id)
        return _resultado(mensagens=[_msg("Pedido cancelado. Quando quiser recomeçar, "
                                          "e so mandar um *oi*. 👋")], encerrar=True)
    if n in ("atendente", "humano", "falar com atendente", "quero falar com alguem",
             "falar com humano", "/atendente"):
        return transferir(sessao, "cliente solicitou atendimento humano")

    # sessao ja transferida: bot fica em silencio
    if sessao.transferido:
        return _resultado()

    # pedido ja finalizado
    if sessao.finalizado:
        return _resultado(mensagens=[_msg("Seu pedido já foi registrado! Nossa equipe está "
                                          "cuidando dele. 😊\nPara fazer um novo pedido, "
                                          "escreva *reiniciar*.")])

    # resposta ao lembrete de inatividade
    if sessao.lembrete_enviado and n in ("continuar", "sim", "estou", "to aqui", "1"):
        sessao.toca()
        txt, ops = pergunta(sessao)
        return _resultado(mensagens=[_msg("Ótimo, vamos continuar! 😄"), _msg(txt, ops)])

    sessao.toca()

    if not aplicar(sessao, texto):
        sessao.erros += 1
        if sessao.erros >= MAX_ERROS:
            return transferir(sessao, f"3 respostas invalidas seguidas na etapa '{sessao.step}'")
        _, ops = pergunta(sessao)
        return _resultado(mensagens=[_msg(erro_msg(sessao.step, ops))])

    sessao.erros = 0
    sessao.step = proximo(sessao)

    if sessao.step == "fim":
        sessao.finalizado = True
        pedido = montar_pedido(sessao)
        salvar_pedido(pedido, sessao)
        tel = formatar_telefone(sessao.dados.get("telefone", ""))
        final = ("✅ Recebemos todas as suas informações com sucesso!\n\n"
                 "Nossa equipe já está analisando as melhores opções e entrará em contato "
                 f"em instantes pelo seu WhatsApp {tel}.\n\n"
                 "Obrigado por escolher a Voei Barato! ✈️")
        return _resultado(mensagens=[_msg(final)], pedido=pedido)

    txt, ops = pergunta(sessao)
    return _resultado(mensagens=[_msg(txt, ops)])


# ---------------------------------------------------------------- inatividade

def verificar_inatividade():
    """
    Roda periodicamente. Devolve lista de acoes:
      {"sessao": s, "tipo": "lembrete"|"encerrar", "mensagens": [...]}
    """
    acoes = []
    with _LOCK:
        itens = list(SESSOES.items())
    for chave, s in itens:
        if s.transferido or s.finalizado:
            continue
        inativa = s.inativa_min()
        if not s.lembrete_enviado and inativa >= TIMEOUT_MIN:
            s.lembrete_enviado = True
            nome = s.nome or "tudo bem"
            acoes.append({
                "sessao": s, "tipo": "lembrete",
                "mensagens": [_msg(f"Oi {nome}, ainda está aí? 😊\n"
                                   "Se preferir, posso te transferir para um atendente.",
                                   ["Continuar", "Falar com atendente"])]
            })
        elif s.lembrete_enviado and inativa >= TIMEOUT_MIN * 2:
            with _LOCK:
                SESSOES.pop(chave, None)
            acoes.append({"sessao": s, "tipo": "encerrar", "mensagens": []})
    return acoes


def loop_inatividade(executor, intervalo=60):
    """Thread que checa inatividade. 'executor' recebe cada acao."""
    def _run():
        while True:
            try:
                for acao in verificar_inatividade():
                    try:
                        executor(acao)
                    except Exception as e:
                        logging.error(f"Erro no executor de inatividade: {e}")
            except Exception as e:
                logging.error(f"Erro no loop de inatividade: {e}")
            time.sleep(intervalo)
    t = threading.Thread(target=_run, daemon=True)
    t.start()
    return t
