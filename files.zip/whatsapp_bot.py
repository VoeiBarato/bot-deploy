"""
Voei Barato - Bot WhatsApp (v2)
Recebe webhooks da Evolution API e responde via REST.
Toda a logica de conversa fica em fluxo.py
"""

import os
import time
import logging
import requests
from flask import Flask, request

import fluxo

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s - %(levelname)s - %(message)s")

EVOLUTION_URL = os.getenv("EVOLUTION_URL", "http://evolution-api:8080").rstrip("/")
EVOLUTION_KEY = os.getenv("EVOLUTION_KEY", "")
INSTANCE = os.getenv("INSTANCE_NAME", "voeibarato")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
GRUPO_ID = os.getenv("GRUPO_ID", "")
CANAL = "WhatsApp"

app = Flask(__name__)


# ------------------------------------------------------------- envio WhatsApp

def enviar(numero, texto, opcoes=None):
    if opcoes:
        lista = "\n".join(f"*{i+1}* - {o}" for i, o in enumerate(opcoes))
        texto = f"{texto}\n\n{lista}\n\n_Responda com o numero ou o nome da opcao._"
    url = f"{EVOLUTION_URL}/message/sendText/{INSTANCE}"
    headers = {"apikey": EVOLUTION_KEY, "Content-Type": "application/json"}
    corpos = [
        {"number": numero, "text": texto},                       # Evolution v2
        {"number": numero, "textMessage": {"text": texto}},      # Evolution v1
    ]
    for corpo in corpos:
        try:
            r = requests.post(url, json=corpo, headers=headers, timeout=20)
            if r.status_code < 300:
                return True
            logging.warning(f"Evolution respondeu {r.status_code}: {r.text[:200]}")
        except Exception as e:
            logging.error(f"Erro ao enviar WhatsApp: {e}")
    return False


# ------------------------------------------------------------- aviso Telegram

def avisar_grupo(texto):
    if not (BOT_TOKEN and GRUPO_ID):
        logging.warning("BOT_TOKEN/GRUPO_ID ausentes - nada enviado ao grupo")
        return
    try:
        requests.post(f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                      json={"chat_id": GRUPO_ID, "text": texto}, timeout=20)
    except Exception as e:
        logging.error(f"Erro ao avisar grupo do Telegram: {e}")


def entregar(numero, resultado):
    for m in resultado["mensagens"]:
        enviar(numero, m["texto"], m.get("opcoes"))
        time.sleep(0.6)   # evita bloqueio por flood
    if resultado.get("pedido"):
        avisar_grupo(resultado["pedido"])
    if resultado.get("alerta"):
        avisar_grupo(resultado["alerta"])


def executor_inatividade(acao):
    s = acao["sessao"]
    if s.canal != CANAL:
        return
    for m in acao["mensagens"]:
        enviar(s.user_id, m["texto"], m.get("opcoes"))
    if acao["tipo"] == "encerrar":
        logging.info(f"Sessao encerrada por inatividade: {s.user_id}")


# ------------------------------------------------------------- webhook

def extrair_texto(msg):
    if not isinstance(msg, dict):
        return ""
    return (msg.get("conversation")
            or (msg.get("extendedTextMessage") or {}).get("text")
            or (msg.get("imageMessage") or {}).get("caption")
            or (msg.get("videoMessage") or {}).get("caption")
            or (msg.get("buttonsResponseMessage") or {}).get("selectedDisplayText")
            or ((msg.get("listResponseMessage") or {}).get("singleSelectReply") or {}).get("selectedRowId")
            or (msg.get("templateButtonReplyMessage") or {}).get("selectedDisplayText")
            or "")


@app.route("/webhook", methods=["POST"])
@app.route("/webhook/<path:resto>", methods=["POST"])
def webhook(resto=None):
    try:
        data = request.get_json(force=True, silent=True) or {}
        evento = str(data.get("event", "")).lower().replace("_", ".")
        if evento and "messages" not in evento:
            return "ok", 200

        pacote = data.get("data", data)
        itens = pacote if isinstance(pacote, list) else [pacote]

        for item in itens:
            if not isinstance(item, dict):
                continue
            key = item.get("key", {}) or {}
            if key.get("fromMe"):
                continue
            jid = key.get("remoteJid", "") or ""
            if not jid or "@g.us" in jid or "status@" in jid:
                continue          # ignora grupos e status
            numero = jid.split("@")[0].split(":")[0]
            texto = extrair_texto(item.get("message", {}))
            if not texto:
                enviar(numero, "Por enquanto eu entendo apenas mensagens de texto. 😊")
                continue

            logging.info(f"[{numero}] {texto[:60]}")
            s = fluxo.get_sessao(CANAL, numero)
            if not s.iniciada:
                entregar(numero, fluxo.iniciar(s))
            else:
                entregar(numero, fluxo.processar(s, texto))
        return "ok", 200
    except Exception as e:
        logging.error(f"Erro no webhook: {e}")
        return "ok", 200


@app.route("/health", methods=["GET"])
def health():
    return {"status": "ok", "sessoes": len(fluxo.SESSOES)}, 200


@app.route("/sessoes", methods=["GET"])
def sessoes():
    out = []
    for chave, s in list(fluxo.SESSOES.items()):
        out.append({"chave": chave, "etapa": s.step, "nome": s.nome,
                    "transferido": s.transferido, "finalizado": s.finalizado,
                    "inativa_min": round(s.inativa_min(), 1)})
    return {"total": len(out), "sessoes": out}, 200


@app.route("/reset/<numero>", methods=["POST", "GET"])
def reset(numero):
    """Libera um numero que estava em atendimento humano."""
    fluxo.apagar_sessao(CANAL, numero)
    return {"ok": True, "numero": numero}, 200


if __name__ == "__main__":
    logging.info("Iniciando Voei Barato Bot (WhatsApp) v2...")
    fluxo.loop_inatividade(executor_inatividade, intervalo=60)
    app.run(host="0.0.0.0", port=5001)
