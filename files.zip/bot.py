"""
Voei Barato - Bot Telegram (v2)
Usa a API HTTP do Telegram diretamente (long polling) - so precisa de 'requests'.
Toda a logica de conversa fica em fluxo.py
"""

import os
import time
import logging
import requests

import fluxo

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s - %(levelname)s - %(message)s")

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
GRUPO_ID = os.getenv("GRUPO_ID", "")
API = f"https://api.telegram.org/bot{BOT_TOKEN}"
CANAL = "Telegram"


def api(metodo, payload):
    try:
        r = requests.post(f"{API}/{metodo}", json=payload, timeout=40)
        return r.json()
    except Exception as e:
        logging.error(f"Erro na API do Telegram ({metodo}): {e}")
        return {}


def enviar(chat_id, texto, opcoes=None):
    payload = {"chat_id": chat_id, "text": texto, "parse_mode": "Markdown"}
    if opcoes:
        payload["reply_markup"] = {
            "keyboard": [[o] for o in opcoes],
            "resize_keyboard": True,
            "one_time_keyboard": True,
        }
    else:
        payload["reply_markup"] = {"remove_keyboard": True}
    res = api("sendMessage", payload)
    if not res.get("ok"):
        # se o Markdown quebrar, reenvia sem formatacao
        payload.pop("parse_mode", None)
        api("sendMessage", payload)


def avisar_grupo(texto):
    if not GRUPO_ID:
        logging.warning("GRUPO_ID nao configurado - pedido nao enviado ao grupo")
        return
    api("sendMessage", {"chat_id": GRUPO_ID, "text": texto})


def entregar(chat_id, resultado):
    for m in resultado["mensagens"]:
        enviar(chat_id, m["texto"], m.get("opcoes"))
        time.sleep(0.2)
    if resultado.get("pedido"):
        avisar_grupo(resultado["pedido"])
    if resultado.get("alerta"):
        avisar_grupo(resultado["alerta"])


def executor_inatividade(acao):
    s = acao["sessao"]
    if s.canal != CANAL:
        return
    for m in acao["mensagens"]:
        enviar(s.user_id, m["texto"], m.get("opcoes"))
    if acao["tipo"] == "encerrar":
        logging.info(f"Sessao encerrada por inatividade: {s.user_id}")


def tratar(update):
    msg = update.get("message") or update.get("edited_message")
    if not msg:
        return
    chat = msg.get("chat", {})
    chat_id = chat.get("id")
    texto = msg.get("text", "")

    # comando utilitario para descobrir o ID do grupo
    if texto.strip().startswith("/id"):
        enviar(chat_id, f"ID deste chat: `{chat_id}`")
        return

    # ignora mensagens de grupo (o bot so atende no privado)
    if chat.get("type") != "private":
        return
    if not texto:
        enviar(chat_id, "Por enquanto eu entendo apenas mensagens de texto. 😊")
        return

    s = fluxo.get_sessao(CANAL, chat_id)
    if not s.iniciada:
        # primeira mensagem: dispara a saudacao e pede o nome
        entregar(chat_id, fluxo.iniciar(s))
        return

    entregar(chat_id, fluxo.processar(s, texto))


def main():
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN nao configurado")
    logging.info("Iniciando Voei Barato Bot (Telegram) v2...")
    fluxo.loop_inatividade(executor_inatividade, intervalo=60)

    offset = None
    while True:
        try:
            r = requests.get(f"{API}/getUpdates",
                             params={"offset": offset, "timeout": 30},
                             timeout=40)
            data = r.json()
            for up in data.get("result", []):
                offset = up["update_id"] + 1
                try:
                    tratar(up)
                except Exception as e:
                    logging.error(f"Erro ao tratar update: {e}")
        except requests.exceptions.Timeout:
            continue
        except Exception as e:
            logging.error(f"Erro no polling: {e}")
            time.sleep(5)


if __name__ == "__main__":
    main()
